"use client"

import type React from "react"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Edit, Trash2, Plus, CalendarIcon } from "lucide-react"
import { v4 as uuidv4 } from "uuid"
import { format, subDays } from "date-fns"
import { es } from "date-fns/locale"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface Referee {
  id: string
  name: string
  category: string
}

interface Championship {
  id: string
  name: string
}

interface AttendanceRecord {
  id: string
  refereeId: string
  date: string
  present: boolean
}

interface Assignment {
  id: string
  championshipId: string
  refereeId: string
  matchName: string
  matchDate: string
  location: string
  role: string
  notes: string
}

interface AssignmentManagerProps {
  referees: Referee[]
  championships: Championship[]
  attendance: AttendanceRecord[]
  assignments: Assignment[]
  onAddAssignment: (assignment: Assignment) => void
  onUpdateAssignment: (id: string, assignment: Assignment) => void
  onDeleteAssignment: (id: string) => void
}

export default function AssignmentManager({
  referees,
  championships,
  attendance,
  assignments,
  onAddAssignment,
  onUpdateAssignment,
  onDeleteAssignment,
}: AssignmentManagerProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [newAssignment, setNewAssignment] = useState<Assignment>({
    id: "",
    championshipId: "",
    refereeId: "",
    matchName: "",
    matchDate: format(new Date(), "yyyy-MM-dd"),
    location: "",
    role: "Árbitro Principal",
    notes: "",
  })
  const [editingAssignment, setEditingAssignment] = useState<Assignment | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [matchDate, setMatchDate] = useState<Date>(new Date())
  const [selectedChampionship, setSelectedChampionship] = useState<string>("")

  // Calcular árbitros elegibles basados en asistencia
  const eligibleReferees = useMemo(() => {
    // Consideramos elegibles a los árbitros que han asistido al menos al 70% de las sesiones
    // en los últimos 30 días
    const today = new Date()
    const thirtyDaysAgo = subDays(today, 30)

    const attendanceStats: { [key: string]: { present: number; total: number } } = {}

    // Inicializar contadores para cada árbitro
    referees.forEach((referee) => {
      attendanceStats[referee.id] = { present: 0, total: 0 }
    })

    // Contar asistencias en los últimos 30 días
    attendance.forEach((record) => {
      const recordDate = new Date(record.date)
      if (recordDate >= thirtyDaysAgo && recordDate <= today) {
        if (attendanceStats[record.refereeId]) {
          attendanceStats[record.refereeId].total++
          if (record.present) {
            attendanceStats[record.refereeId].present++
          }
        }
      }
    })

    // Filtrar árbitros con al menos 70% de asistencia
    return referees.filter((referee) => {
      const stats = attendanceStats[referee.id]
      if (stats.total === 0) return true // Si no hay registros, lo consideramos elegible
      return stats.present / stats.total >= 0.7
    })
  }, [referees, attendance])

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onAddAssignment({
      ...newAssignment,
      id: uuidv4(),
      matchDate: format(matchDate, "yyyy-MM-dd"),
    })
    setNewAssignment({
      id: "",
      championshipId: "",
      refereeId: "",
      matchName: "",
      matchDate: format(new Date(), "yyyy-MM-dd"),
      location: "",
      role: "Árbitro Principal",
      notes: "",
    })
    setMatchDate(new Date())
    setIsAddDialogOpen(false)
  }

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (editingAssignment) {
      onUpdateAssignment(editingAssignment.id, {
        ...editingAssignment,
        matchDate: format(matchDate, "yyyy-MM-dd"),
      })
      setEditingAssignment(null)
      setIsEditDialogOpen(false)
    }
  }

  const startEdit = (assignment: Assignment) => {
    setEditingAssignment({ ...assignment })
    setMatchDate(new Date(assignment.matchDate))
    setIsEditDialogOpen(true)
  }

  const filteredAssignments = assignments.filter((assignment) => {
    // Filtrar por término de búsqueda
    const matchName = assignment.matchName.toLowerCase().includes(searchTerm.toLowerCase())
    const location = assignment.location.toLowerCase().includes(searchTerm.toLowerCase())
    const referee = referees.find((r) => r.id === assignment.refereeId)
    const refereeName = referee ? referee.name.toLowerCase().includes(searchTerm.toLowerCase()) : false

    // Filtrar por campeonato seleccionado
    const championshipMatch = selectedChampionship ? assignment.championshipId === selectedChampionship : true

    return (matchName || location || refereeName) && championshipMatch
  })

  const getRefereeById = (id: string) => {
    return referees.find((referee) => referee.id === id)
  }

  const getChampionshipById = (id: string) => {
    return championships.find((championship) => championship.id === id)
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="flex gap-2 w-2/3">
          <Input
            placeholder="Buscar designaciones..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-sm"
          />
          <Select value={selectedChampionship} onValueChange={setSelectedChampionship}>
            <SelectTrigger className="w-[250px]">
              <SelectValue placeholder="Todos los campeonatos" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Todos los campeonatos</SelectItem>
              {championships.map((championship) => (
                <SelectItem key={championship.id} value={championship.id}>
                  {championship.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Agregar Designación
            </Button>
          </DialogTrigger>
          <DialogContent>
            <form onSubmit={handleAddSubmit}>
              <DialogHeader>
                <DialogTitle>Agregar Nueva Designación</DialogTitle>
                <DialogDescription>Asigna un árbitro a un partido.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="championshipId" className="text-right">
                    Campeonato
                  </Label>
                  <Select
                    value={newAssignment.championshipId}
                    onValueChange={(value) => setNewAssignment({ ...newAssignment, championshipId: value })}
                    required
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Seleccionar campeonato" />
                    </SelectTrigger>
                    <SelectContent>
                      {championships.map((championship) => (
                        <SelectItem key={championship.id} value={championship.id}>
                          {championship.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="refereeId" className="text-right">
                    Árbitro
                  </Label>
                  <Select
                    value={newAssignment.refereeId}
                    onValueChange={(value) => setNewAssignment({ ...newAssignment, refereeId: value })}
                    required
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Seleccionar árbitro" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="disabled_1" disabled>
                        Árbitros Elegibles
                      </SelectItem>
                      {eligibleReferees.map((referee) => (
                        <SelectItem key={referee.id} value={referee.id}>
                          {referee.name} ({referee.category})
                        </SelectItem>
                      ))}
                      {eligibleReferees.length < referees.length && (
                        <>
                          <SelectItem value="disabled_2" disabled>
                            Árbitros No Elegibles (Baja Asistencia)
                          </SelectItem>
                          {referees
                            .filter((r) => !eligibleReferees.some((er) => er.id === r.id))
                            .map((referee) => (
                              <SelectItem key={referee.id} value={referee.id}>
                                {referee.name} ({referee.category}) - Baja Asistencia
                              </SelectItem>
                            ))}
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="matchName" className="text-right">
                    Partido
                  </Label>
                  <Input
                    id="matchName"
                    value={newAssignment.matchName}
                    onChange={(e) => setNewAssignment({ ...newAssignment, matchName: e.target.value })}
                    className="col-span-3"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="matchDate" className="text-right">
                    Fecha
                  </Label>
                  <div className="col-span-3">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {format(matchDate, "PPP", { locale: es })}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={matchDate}
                          onSelect={(date) => date && setMatchDate(date)}
                          initialFocus
                          locale={es}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="location" className="text-right">
                    Ubicación
                  </Label>
                  <Input
                    id="location"
                    value={newAssignment.location}
                    onChange={(e) => setNewAssignment({ ...newAssignment, location: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="role" className="text-right">
                    Rol
                  </Label>
                  <Select
                    value={newAssignment.role}
                    onValueChange={(value) => setNewAssignment({ ...newAssignment, role: value })}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Seleccionar rol" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Árbitro Principal">Árbitro Principal</SelectItem>
                      <SelectItem value="Árbitro Asistente">Árbitro Asistente</SelectItem>
                      <SelectItem value="Cuarto Árbitro">Cuarto Árbitro</SelectItem>
                      <SelectItem value="VAR">VAR</SelectItem>
                      <SelectItem value="AVAR">AVAR</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="notes" className="text-right">
                    Notas
                  </Label>
                  <Textarea
                    id="notes"
                    value={newAssignment.notes}
                    onChange={(e) => setNewAssignment({ ...newAssignment, notes: e.target.value })}
                    className="col-span-3"
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Guardar</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {eligibleReferees.length === 0 && referees.length > 0 && (
        <Card className="bg-amber-50 border-amber-200 mb-4">
          <CardContent className="pt-6">
            <p className="text-amber-800">
              No hay árbitros con suficiente asistencia para ser elegibles automáticamente. Considera revisar los
              registros de asistencia.
            </p>
          </CardContent>
        </Card>
      )}

      {referees.length === 0 || championships.length === 0 ? (
        <Card>
          <CardContent className="pt-6 text-center text-muted-foreground">
            {referees.length === 0 && championships.length === 0
              ? "Necesitas agregar árbitros y campeonatos antes de crear designaciones."
              : referees.length === 0
                ? "Necesitas agregar árbitros antes de crear designaciones."
                : "Necesitas agregar campeonatos antes de crear designaciones."}
          </CardContent>
        </Card>
      ) : assignments.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground">
          No hay designaciones registradas. Agrega una para comenzar.
        </div>
      ) : (
        <div className="border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Campeonato</TableHead>
                <TableHead>Partido</TableHead>
                <TableHead>Fecha</TableHead>
                <TableHead>Árbitro</TableHead>
                <TableHead>Rol</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAssignments.map((assignment) => {
                const referee = getRefereeById(assignment.refereeId)
                const championship = getChampionshipById(assignment.championshipId)

                return (
                  <TableRow key={assignment.id}>
                    <TableCell>{championship?.name || "Desconocido"}</TableCell>
                    <TableCell>{assignment.matchName}</TableCell>
                    <TableCell>{format(new Date(assignment.matchDate), "dd/MM/yyyy")}</TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span>{referee?.name || "Desconocido"}</span>
                        {referee && !eligibleReferees.some((r) => r.id === referee.id) && (
                          <Badge variant="outline" className="text-xs mt-1 bg-amber-50 text-amber-800 border-amber-200">
                            Baja Asistencia
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{assignment.role}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" onClick={() => startEdit(assignment)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Esta acción eliminará permanentemente esta designación del sistema y no se puede
                                deshacer.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction onClick={() => onDeleteAssignment(assignment.id)}>
                                Eliminar
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          {editingAssignment && (
            <form onSubmit={handleEditSubmit}>
              <DialogHeader>
                <DialogTitle>Editar Designación</DialogTitle>
                <DialogDescription>Actualiza la información de la designación.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-championshipId" className="text-right">
                    Campeonato
                  </Label>
                  <Select
                    value={editingAssignment.championshipId}
                    onValueChange={(value) => setEditingAssignment({ ...editingAssignment, championshipId: value })}
                    required
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Seleccionar campeonato" />
                    </SelectTrigger>
                    <SelectContent>
                      {championships.map((championship) => (
                        <SelectItem key={championship.id} value={championship.id}>
                          {championship.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-refereeId" className="text-right">
                    Árbitro
                  </Label>
                  <Select
                    value={editingAssignment.refereeId}
                    onValueChange={(value) => setEditingAssignment({ ...editingAssignment, refereeId: value })}
                    required
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Seleccionar árbitro" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="disabled_1" disabled>
                        Árbitros Elegibles
                      </SelectItem>
                      {eligibleReferees.map((referee) => (
                        <SelectItem key={referee.id} value={referee.id}>
                          {referee.name} ({referee.category})
                        </SelectItem>
                      ))}
                      {eligibleReferees.length < referees.length && (
                        <>
                          <SelectItem value="disabled_2" disabled>
                            Árbitros No Elegibles (Baja Asistencia)
                          </SelectItem>
                          {referees
                            .filter((r) => !eligibleReferees.some((er) => er.id === r.id))
                            .map((referee) => (
                              <SelectItem key={referee.id} value={referee.id}>
                                {referee.name} ({referee.category}) - Baja Asistencia
                              </SelectItem>
                            ))}
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-matchName" className="text-right">
                    Partido
                  </Label>
                  <Input
                    id="edit-matchName"
                    value={editingAssignment.matchName}
                    onChange={(e) => setEditingAssignment({ ...editingAssignment, matchName: e.target.value })}
                    className="col-span-3"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-matchDate" className="text-right">
                    Fecha
                  </Label>
                  <div className="col-span-3">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {format(matchDate, "PPP", { locale: es })}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={matchDate}
                          onSelect={(date) => date && setMatchDate(date)}
                          initialFocus
                          locale={es}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-location" className="text-right">
                    Ubicación
                  </Label>
                  <Input
                    id="edit-location"
                    value={editingAssignment.location}
                    onChange={(e) => setEditingAssignment({ ...editingAssignment, location: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-role" className="text-right">
                    Rol
                  </Label>
                  <Select
                    value={editingAssignment.role}
                    onValueChange={(value) => setEditingAssignment({ ...editingAssignment, role: value })}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Seleccionar rol" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Árbitro Principal">Árbitro Principal</SelectItem>
                      <SelectItem value="Árbitro Asistente">Árbitro Asistente</SelectItem>
                      <SelectItem value="Cuarto Árbitro">Cuarto Árbitro</SelectItem>
                      <SelectItem value="VAR">VAR</SelectItem>
                      <SelectItem value="AVAR">AVAR</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-notes" className="text-right">
                    Notas
                  </Label>
                  <Textarea
                    id="edit-notes"
                    value={editingAssignment.notes}
                    onChange={(e) => setEditingAssignment({ ...editingAssignment, notes: e.target.value })}
                    className="col-span-3"
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Actualizar</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
